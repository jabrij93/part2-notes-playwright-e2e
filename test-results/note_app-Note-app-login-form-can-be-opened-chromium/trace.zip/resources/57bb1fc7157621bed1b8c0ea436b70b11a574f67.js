import {
  require_react
} from "/node_modules/.vite/deps/chunk-BZN7XFWI.js?v=ea365ae8";
import "/node_modules/.vite/deps/chunk-76J2PTFD.js?v=ea365ae8";
export default require_react();
//# sourceMappingURL=react.js.map
