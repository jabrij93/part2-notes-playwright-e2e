import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NoteForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ea365ae8"; const useState = __vite__cjsImport3_react["useState"];
const NoteForm = ({
  createNote
}) => {
  _s();
  const [newNote, setNewNote] = useState("");
  const [newNote2, setNewNote2] = useState("");
  const addNote = (event) => {
    event.preventDefault();
    createNote({
      content: newNote,
      important: true
    });
    setNewNote("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "formDiv", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create a new note" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addNote, children: [
      /* @__PURE__ */ jsxDEV("input", { value: newNote, onChange: (event) => setNewNote(event.target.value), id: "note-input" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx",
        lineNumber: 20,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "save" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx",
        lineNumber: 21,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx",
      lineNumber: 19,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_s(NoteForm, "hJsYM6pLih0+Rr36lh3lz7wW44I=");
_c = NoteForm;
export default NoteForm;
var _c;
$RefreshReg$(_c, "NoteForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-frontend/src/components/NoteForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJTCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDTSxVQUFVQyxXQUFXLElBQUlQLFNBQVMsRUFBRTtBQUUzQyxRQUFNUSxVQUFXQyxXQUFVO0FBQ3pCQSxVQUFNQyxlQUFlO0FBQ3JCUixlQUFXO0FBQUEsTUFDVFMsU0FBU1A7QUFBQUEsTUFDVFEsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNEUCxlQUFXLEVBQUU7QUFBQSxFQUNmO0FBRUUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLDJCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLFVBQUssVUFBVUcsU0FDZDtBQUFBLDZCQUFDLFdBQ0MsT0FBT0osU0FDUCxVQUFVSyxXQUFTSixXQUFXSSxNQUFNSSxPQUFPQyxLQUFLLEdBQ2hELElBQUcsZ0JBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdpQjtBQUFBLE1BRWpCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsU0FONUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFTjtBQUFDWCxHQTFCS0YsVUFBUTtBQUFBYyxLQUFSZDtBQTRCTixlQUFlQTtBQUFRLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIk5vdGVGb3JtIiwiY3JlYXRlTm90ZSIsIl9zIiwibmV3Tm90ZSIsInNldE5ld05vdGUiLCJuZXdOb3RlMiIsInNldE5ld05vdGUyIiwiYWRkTm90ZSIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJjb250ZW50IiwiaW1wb3J0YW50IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGVGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBOb3RlRm9ybSA9ICh7IGNyZWF0ZU5vdGUgfSkgPT4ge1xuICBjb25zdCBbbmV3Tm90ZSwgc2V0TmV3Tm90ZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld05vdGUyLCBzZXROZXdOb3RlMl0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBhZGROb3RlID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNyZWF0ZU5vdGUoe1xuICAgICAgY29udGVudDogbmV3Tm90ZSxcbiAgICAgIGltcG9ydGFudDogdHJ1ZVxuICAgIH0pXG4gICAgc2V0TmV3Tm90ZSgnJylcbiAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybURpdlwiPlxuICAgICAgICA8aDI+Q3JlYXRlIGEgbmV3IG5vdGU8L2gyPlxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17YWRkTm90ZX0+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB2YWx1ZT17bmV3Tm90ZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtldmVudCA9PiBzZXROZXdOb3RlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBpZD0nbm90ZS1pbnB1dCdcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPnNhdmU8L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RlRm9ybSJdLCJmaWxlIjoiL1VzZXJzL2FkbWluL01pbmkgUHJvamVjdHMvcGFydDItbm90ZXMtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90ZUZvcm0uanN4In0=