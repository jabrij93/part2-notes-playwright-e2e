import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({
  message,
  type
}) => {
  if (!message)
    return null;
  const notificationStyle = type === "error" ? "notification error" : "notification success";
  return /* @__PURE__ */ jsxDEV("div", { className: notificationStyle, children: message }, void 0, false, {
    fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Notification.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07QUFOTixPQUFNQSxvQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFLLE1BQU07QUFDeEMsTUFBSSxDQUFDRDtBQUFTLFdBQU87QUFFckIsUUFBTUUsb0JBQW9CRCxTQUFTLFVBQVUsdUJBQXVCO0FBRXBFLFNBQ0UsdUJBQUMsU0FBSSxXQUFXQyxtQkFDYkYscUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRU47QUFBQ0csS0FWS0o7QUFZTixlQUFlQTtBQUFZLElBQUFJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOb3RpZmljYXRpb24iLCJtZXNzYWdlIiwidHlwZSIsIm5vdGlmaWNhdGlvblN0eWxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UsIHR5cGUgfSkgPT4ge1xuICAgIGlmICghbWVzc2FnZSkgcmV0dXJuIG51bGw7IC8vIERvbid0IHJlbmRlciBhbnl0aGluZyBpZiB0aGUgbWVzc2FnZSBpcyBudWxsIG9yIGVtcHR5XG5cbiAgICBjb25zdCBub3RpZmljYXRpb25TdHlsZSA9IHR5cGUgPT09ICdlcnJvcicgPyAnbm90aWZpY2F0aW9uIGVycm9yJyA6ICdub3RpZmljYXRpb24gc3VjY2Vzcyc7XG5cbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9e25vdGlmaWNhdGlvblN0eWxlfT5cbiAgICAgICAge21lc3NhZ2V9XG4gICAgICA8L2Rpdj5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbiJdLCJmaWxlIjoiL1VzZXJzL2FkbWluL01pbmkgUHJvamVjdHMvcGFydDItbm90ZXMtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9