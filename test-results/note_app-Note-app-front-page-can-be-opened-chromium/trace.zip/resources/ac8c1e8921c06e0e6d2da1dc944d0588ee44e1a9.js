import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ea365ae8"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Note from "/src/components/Note.jsx";
import noteService from "/src/services/noteService.js";
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx";
import LoginForm from "/src/components/LoginForm.jsx";
import NoteForm from "/src/components/NoteForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [notes, setNotes] = useState([]);
  const [showAll, setShowAll] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [notifications, setNotifications] = useState(null);
  const [user, setUser] = useState(null);
  useEffect(() => {
    noteService.getAll().then((initialNotes) => {
      setNotes(initialNotes);
    });
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedNoteappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      noteService.setToken(user2.token);
    }
  }, []);
  const noteFormRef = useRef();
  const addNote = (noteObject) => {
    noteFormRef.current.toggleVisibility();
    noteService.create(noteObject).then((returnedNote) => {
      setNotes(notes.concat(returnedNote));
    });
  };
  const handleLogin = async (userCredentials) => {
    try {
      const user2 = await loginService.login(userCredentials);
      window.localStorage.setItem("loggedNoteappUser", JSON.stringify(user2));
      noteService.setToken(user2.token);
      setUser(user2);
      setNotifications({
        message: `Logging in as ${user2.name}`,
        type: "success"
      });
    } catch (exception) {
      setNotifications({
        message: "Wrong credentials",
        type: "error"
      });
    }
    setTimeout(() => {
      setNotifications(null);
    }, 5e3);
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedNoteappUser");
    setUser(null);
    setUsername("");
    setPassword("");
    setNotifications({
      message: "User logged out",
      type: "info"
    });
    setTimeout(() => {
      setNotifications(null);
    }, 5e3);
  };
  const notesToShow = showAll ? notes : notes.filter((note) => note.important);
  const toggleImportanceOf = (id) => {
    const note = notes.find((n) => n.id === id);
    const changedNote = {
      ...note,
      important: !note.important
    };
    noteService.update(id, changedNote).then((returnedNote) => {
      setNotes(notes.map((note2) => note2.id === id ? returnedNote : note2));
    }).catch((error) => {
      alert(`The note '${note.content}' was already deleted from server`);
      setNotes(notes.filter((n) => n.id !== id));
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Notes" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notifications?.message, type: notifications?.type }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    user === null ? /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "login", children: /* @__PURE__ */ jsxDEV(LoginForm, { userLogin: handleLogin }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 90,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 89,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 88,
      columnNumber: 24
    }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged in"
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
        lineNumber: 93,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
        lineNumber: 94,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Add Note", ref: noteFormRef, children: /* @__PURE__ */ jsxDEV(NoteForm, { createNote: addNote }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
        lineNumber: 96,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
        lineNumber: 95,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 92,
      columnNumber: 18
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowAll(!showAll), children: [
      "Show ",
      showAll ? "important" : "all"
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: notesToShow.map((note) => /* @__PURE__ */ jsxDEV(Note, { note, toggleImportance: () => toggleImportanceOf(note.id) }, note.id, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 103,
      columnNumber: 34
    }, this)) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { style: {
      color: "green",
      fontStyle: "italic",
      fontSize: "25px"
    }, children: "Note app, Department of Computer Science, University of Helsinki 2024" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
      lineNumber: 106,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx",
    lineNumber: 85,
    columnNumber: 10
  }, this);
};
_s(App, "NFOt5hzajbGw9m1uNcxhH7i+ihM=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZGTixPQUFPQSxTQUFTQyxVQUFVQyxXQUFXQyxjQUFjO0FBQ25ELE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxTQUFTQyxVQUFVLElBQUlmLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0IsVUFBVUMsV0FBVyxJQUFJbkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29CLGVBQWVDLGdCQUFnQixJQUFJckIsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3NCLE1BQU1DLE9BQU8sSUFBSXZCLFNBQVMsSUFBSTtBQUVyQ0MsWUFBVSxNQUFNO0FBQ2RHLGdCQUNHb0IsT0FBTyxFQUNQQyxLQUFLQyxrQkFBZ0I7QUFDcEJiLGVBQVNhLFlBQVk7QUFBQSxJQUN6QixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFFTHpCLFlBQVUsTUFBTTtBQUNkLFVBQU0wQixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsbUJBQW1CO0FBQ3RFLFFBQUlILGdCQUFnQjtBQUNsQixZQUFNTCxRQUFPUyxLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDSixjQUFRRCxLQUFJO0FBQ1psQixrQkFBWTZCLFNBQVNYLE1BQUtZLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsY0FBY2pDLE9BQU87QUFFM0IsUUFBTWtDLFVBQVdDLGdCQUFlO0FBQzlCRixnQkFBWUcsUUFBUUMsaUJBQWlCO0FBQ3JDbkMsZ0JBQ0dvQyxPQUFPSCxVQUFVLEVBQ2pCWixLQUFLZ0Isa0JBQWdCO0FBQ3BCNUIsZUFBU0QsTUFBTThCLE9BQU9ELFlBQVksQ0FBQztBQUFBLElBQ3ZDLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUUsY0FBYyxPQUFPQyxvQkFBb0I7QUFDN0MsUUFBSTtBQUNGLFlBQU10QixRQUFPLE1BQU1qQixhQUFhd0MsTUFBT0QsZUFBZ0I7QUFDdkRoQixhQUFPQyxhQUFhaUIsUUFBUSxxQkFBcUJmLEtBQUtnQixVQUFVekIsS0FBSSxDQUFDO0FBQ3JFbEIsa0JBQVk2QixTQUFTWCxNQUFLWSxLQUFLO0FBQzdCWCxjQUFRRCxLQUFJO0FBQ1pELHVCQUFpQjtBQUFBLFFBQUUyQixTQUFVLGlCQUFnQjFCLE1BQUsyQixJQUFLO0FBQUEsUUFBR0MsTUFBTTtBQUFBLE1BQVUsQ0FBQztBQUFBLElBQy9FLFNBQVNDLFdBQVc7QUFDaEI5Qix1QkFBaUI7QUFBQSxRQUFFMkIsU0FBUztBQUFBLFFBQXFCRSxNQUFNO0FBQUEsTUFBUSxDQUFDO0FBQUEsSUFDcEU7QUFDQUUsZUFBVyxNQUFNO0FBQ2YvQix1QkFBaUIsSUFBSTtBQUFBLElBQ3ZCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFFQSxRQUFNZ0MsZUFBZUEsTUFBTTtBQUN6QnpCLFdBQU9DLGFBQWF5QixXQUFXLG1CQUFtQjtBQUNsRC9CLFlBQVEsSUFBSTtBQUNaTixnQkFBWSxFQUFFO0FBQ2RFLGdCQUFZLEVBQUU7QUFDZEUscUJBQWlCO0FBQUEsTUFBRTJCLFNBQVM7QUFBQSxNQUFtQkUsTUFBTTtBQUFBLElBQU8sQ0FBQztBQUM3REUsZUFBVyxNQUFNO0FBQ2YvQix1QkFBaUIsSUFBSTtBQUFBLElBQ3ZCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFFQSxRQUFNa0MsY0FBY3pDLFVBQVVGLFFBQVFBLE1BQU00QyxPQUFPQyxVQUFRQSxLQUFLQyxTQUFTO0FBRXpFLFFBQU1DLHFCQUFzQkMsUUFBTztBQUNqQyxVQUFNSCxPQUFPN0MsTUFBTWlELEtBQUtDLE9BQUtBLEVBQUVGLE9BQU9BLEVBQUU7QUFDeEMsVUFBTUcsY0FBYztBQUFBLE1BQUUsR0FBR047QUFBQUEsTUFBTUMsV0FBVyxDQUFDRCxLQUFLQztBQUFBQSxJQUFVO0FBRTFEdEQsZ0JBQVk0RCxPQUFPSixJQUFJRyxXQUFXLEVBQUV0QyxLQUFLZ0Isa0JBQWdCO0FBQ3ZENUIsZUFBU0QsTUFBTXFELElBQUlSLFdBQVFBLE1BQUtHLE9BQU9BLEtBQUtuQixlQUFlZ0IsS0FBSSxDQUFDO0FBQUEsSUFDbEUsQ0FBQyxFQUFFUyxNQUFNQyxXQUFTO0FBQ2hCQyxZQUFPLGFBQVlYLEtBQUtZLE9BQVEsbUNBQWtDO0FBQ2xFeEQsZUFBU0QsTUFBTTRDLE9BQU9NLE9BQUtBLEVBQUVGLE9BQU9BLEVBQUUsQ0FBQztBQUFBLElBQ3pDLENBQUM7QUFBQSxFQUNIO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLFNBQVN4QyxlQUFlNEIsU0FBUyxNQUFNNUIsZUFBZThCLFFBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUU7QUFBQSxJQUN4RTVCLFNBQVMsT0FDUix1QkFBQyxTQUNDLGlDQUFDLGFBQVUsYUFBWSxTQUNuQixpQ0FBQyxhQUNDLFdBQVdxQixlQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDeUIsS0FGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlFLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLElBRUEsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUdyQjtBQUFBQSxhQUFLMkI7QUFBQUEsUUFBSztBQUFBLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLFlBQU8sU0FBU0ksY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLE1BQ3JDLHVCQUFDLGFBQVUsYUFBWSxZQUFXLEtBQUtsQixhQUNyQyxpQ0FBQyxZQUFTLFlBQVlDLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVGLHVCQUFDLFlBQU8sU0FBUyxNQUFNckIsV0FBVyxDQUFDRCxPQUFPLEdBQUU7QUFBQTtBQUFBLE1BQ3BDQSxVQUFVLGNBQWM7QUFBQSxTQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFFBQ0V5QyxzQkFBWVUsSUFBSVIsVUFDZix1QkFBQyxRQUVDLE1BQ0Esa0JBQWtCLE1BQU1FLG1CQUFtQkYsS0FBS0csRUFBRSxLQUY3Q0gsS0FBS0csSUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR3NELENBRXZELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxPQUFFLE9BQU87QUFBQSxNQUFFVSxPQUFPO0FBQUEsTUFBU0MsV0FBVztBQUFBLE1BQVVDLFVBQVU7QUFBQSxJQUFNLEdBQUcscUZBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUk7QUFBQSxPQWpDM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUU3RCxHQWxISUQsS0FBRztBQUFBK0QsS0FBSC9EO0FBb0hOLGVBQWVBO0FBQUksSUFBQStEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiTm90ZSIsIm5vdGVTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwiTG9naW5Gb3JtIiwiTm90ZUZvcm0iLCJUb2dnbGFibGUiLCJBcHAiLCJfcyIsIm5vdGVzIiwic2V0Tm90ZXMiLCJzaG93QWxsIiwic2V0U2hvd0FsbCIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwibm90aWZpY2F0aW9ucyIsInNldE5vdGlmaWNhdGlvbnMiLCJ1c2VyIiwic2V0VXNlciIsImdldEFsbCIsInRoZW4iLCJpbml0aWFsTm90ZXMiLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwibm90ZUZvcm1SZWYiLCJhZGROb3RlIiwibm90ZU9iamVjdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiY3JlYXRlIiwicmV0dXJuZWROb3RlIiwiY29uY2F0IiwiaGFuZGxlTG9naW4iLCJ1c2VyQ3JlZGVudGlhbHMiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJtZXNzYWdlIiwibmFtZSIsInR5cGUiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsIm5vdGVzVG9TaG93IiwiZmlsdGVyIiwibm90ZSIsImltcG9ydGFudCIsInRvZ2dsZUltcG9ydGFuY2VPZiIsImlkIiwiZmluZCIsIm4iLCJjaGFuZ2VkTm90ZSIsInVwZGF0ZSIsIm1hcCIsImNhdGNoIiwiZXJyb3IiLCJhbGVydCIsImNvbnRlbnQiLCJjb2xvciIsImZvbnRTdHlsZSIsImZvbnRTaXplIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgTm90ZSBmcm9tICcuL2NvbXBvbmVudHMvTm90ZSc7XG5pbXBvcnQgbm90ZVNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ub3RlU2VydmljZSc7XG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nO1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uJztcbmltcG9ydCBMb2dpbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ2luRm9ybSc7XG5pbXBvcnQgTm90ZUZvcm0gZnJvbSAnLi9jb21wb25lbnRzL05vdGVGb3JtJztcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSc7XG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW25vdGVzLCBzZXROb3Rlc10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtzaG93QWxsLCBzZXRTaG93QWxsXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKTsgXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBub3RlU2VydmljZVxuICAgICAgLmdldEFsbCgpXG4gICAgICAudGhlbihpbml0aWFsTm90ZXMgPT4ge1xuICAgICAgICBzZXROb3Rlcyhpbml0aWFsTm90ZXMpO1xuICAgIH0pO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkTm90ZWFwcFVzZXInKTtcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKTtcbiAgICAgIHNldFVzZXIodXNlcik7XG4gICAgICBub3RlU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICBjb25zdCBub3RlRm9ybVJlZiA9IHVzZVJlZigpXG5cbiAgY29uc3QgYWRkTm90ZSA9IChub3RlT2JqZWN0KSA9PiB7XG4gICAgbm90ZUZvcm1SZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcbiAgICBub3RlU2VydmljZVxuICAgICAgLmNyZWF0ZShub3RlT2JqZWN0KVxuICAgICAgLnRoZW4ocmV0dXJuZWROb3RlID0+IHtcbiAgICAgICAgc2V0Tm90ZXMobm90ZXMuY29uY2F0KHJldHVybmVkTm90ZSkpO1xuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKHVzZXJDcmVkZW50aWFscykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKCB1c2VyQ3JlZGVudGlhbHMgKTtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkTm90ZWFwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSk7XG4gICAgICBub3RlU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKTtcbiAgICAgICAgc2V0VXNlcih1c2VyKTtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9ucyh7IG1lc3NhZ2U6IGBMb2dnaW5nIGluIGFzICR7dXNlci5uYW1lfWAsIHR5cGU6ICdzdWNjZXNzJyB9KTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9ucyh7IG1lc3NhZ2U6ICdXcm9uZyBjcmVkZW50aWFscycsIHR5cGU6ICdlcnJvcicgfSk7XG4gICAgfVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Tm90aWZpY2F0aW9ucyhudWxsKTtcbiAgICB9LCA1MDAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWROb3RlYXBwVXNlcicpO1xuICAgIHNldFVzZXIobnVsbCk7XG4gICAgc2V0VXNlcm5hbWUoJycpO1xuICAgIHNldFBhc3N3b3JkKCcnKTtcbiAgICBzZXROb3RpZmljYXRpb25zKHsgbWVzc2FnZTogJ1VzZXIgbG9nZ2VkIG91dCcsIHR5cGU6ICdpbmZvJyB9KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbnMobnVsbCk7XG4gICAgfSwgNTAwMCk7XG4gIH07XG5cbiAgY29uc3Qgbm90ZXNUb1Nob3cgPSBzaG93QWxsID8gbm90ZXMgOiBub3Rlcy5maWx0ZXIobm90ZSA9PiBub3RlLmltcG9ydGFudCk7XG5cbiAgY29uc3QgdG9nZ2xlSW1wb3J0YW5jZU9mID0gKGlkKSA9PiB7XG4gICAgY29uc3Qgbm90ZSA9IG5vdGVzLmZpbmQobiA9PiBuLmlkID09PSBpZCk7XG4gICAgY29uc3QgY2hhbmdlZE5vdGUgPSB7IC4uLm5vdGUsIGltcG9ydGFudDogIW5vdGUuaW1wb3J0YW50IH07XG5cbiAgICBub3RlU2VydmljZS51cGRhdGUoaWQsIGNoYW5nZWROb3RlKS50aGVuKHJldHVybmVkTm90ZSA9PiB7XG4gICAgICBzZXROb3Rlcyhub3Rlcy5tYXAobm90ZSA9PiBub3RlLmlkID09PSBpZCA/IHJldHVybmVkTm90ZSA6IG5vdGUpKTtcbiAgICB9KS5jYXRjaChlcnJvciA9PiB7XG4gICAgICBhbGVydChgVGhlIG5vdGUgJyR7bm90ZS5jb250ZW50fScgd2FzIGFscmVhZHkgZGVsZXRlZCBmcm9tIHNlcnZlcmApO1xuICAgICAgc2V0Tm90ZXMobm90ZXMuZmlsdGVyKG4gPT4gbi5pZCAhPT0gaWQpKTtcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDE+Tm90ZXM8L2gxPlxuICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXtub3RpZmljYXRpb25zPy5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb25zPy50eXBlfSAvPlxuICAgICAge3VzZXIgPT09IG51bGwgPyAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD0nbG9naW4nID4gXG4gICAgICAgICAgICAgIDxMb2dpbkZvcm1cbiAgICAgICAgICAgICAgICB1c2VyTG9naW49e2hhbmRsZUxvZ2lufVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Ub2dnbGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8cD57dXNlci5uYW1lfSBsb2dnZWQgaW48L3A+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PmxvZ291dDwvYnV0dG9uPlxuICAgICAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9J0FkZCBOb3RlJyByZWY9e25vdGVGb3JtUmVmfSA+XG4gICAgICAgICAgICA8Tm90ZUZvcm0gY3JlYXRlTm90ZT17YWRkTm90ZX0vPlxuICAgICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dBbGwoIXNob3dBbGwpfT5cbiAgICAgICAgU2hvdyB7c2hvd0FsbCA/ICdpbXBvcnRhbnQnIDogJ2FsbCd9XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDx1bD5cbiAgICAgICAge25vdGVzVG9TaG93Lm1hcChub3RlID0+IChcbiAgICAgICAgICA8Tm90ZSBcbiAgICAgICAgICAgIGtleT17bm90ZS5pZH0gXG4gICAgICAgICAgICBub3RlPXtub3RlfSBcbiAgICAgICAgICAgIHRvZ2dsZUltcG9ydGFuY2U9eygpID0+IHRvZ2dsZUltcG9ydGFuY2VPZihub3RlLmlkKX0gXG4gICAgICAgICAgLz5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuXG4gICAgICA8cCBzdHlsZT17eyBjb2xvcjogJ2dyZWVuJywgZm9udFN0eWxlOiAnaXRhbGljJywgZm9udFNpemU6ICcyNXB4J319Pk5vdGUgYXBwLCBEZXBhcnRtZW50IG9mIENvbXB1dGVyIFNjaWVuY2UsIFVuaXZlcnNpdHkgb2YgSGVsc2lua2kgMjAyNDwvcD5cblxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvYWRtaW4vTWluaSBQcm9qZWN0cy9wYXJ0Mi1ub3Rlcy1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9