import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ea365ae8"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=ea365ae8"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const LoginForm = ({
  userLogin
}) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleLogin = (event) => {
    event.preventDefault();
    userLogin({
      username,
      password
    });
    setUsername("");
    setPassword("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
      lineNumber: 20,
      columnNumber: 8
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", value: username, onChange: (event) => setUsername(event.target.value) }, void 0, false, {
          fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
          lineNumber: 24,
          columnNumber: 12
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
        lineNumber: 22,
        columnNumber: 10
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: (event) => setPassword(event.target.value) }, void 0, false, {
          fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
          lineNumber: 28,
          columnNumber: 12
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
        lineNumber: 26,
        columnNumber: 10
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
        lineNumber: 30,
        columnNumber: 10
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
      lineNumber: 21,
      columnNumber: 8
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(LoginForm, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = LoginForm;
LoginForm.propTypes = {
  userLogin: PropTypes.func.isRequired
};
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JPOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCUCxTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFZQSxDQUFDO0FBQUEsRUFBRUM7QUFBVSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlOLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNPLFVBQVVDLFdBQVcsSUFBSVIsU0FBUyxFQUFFO0FBRTNDLFFBQU1TLGNBQWVDLFdBQVU7QUFDN0JBLFVBQU1DLGVBQWU7QUFDckJSLGNBQVU7QUFBQSxNQUFFRTtBQUFBQSxNQUFVRTtBQUFBQSxJQUFTLENBQUM7QUFDaENELGdCQUFZLEVBQUU7QUFDZEUsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCO0FBRUEsU0FDRyx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFVBQUssVUFBVUMsYUFDZDtBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxlQUFZLFlBQ1osT0FBT0osVUFDUCxVQUFVSyxXQUFPSixZQUFZSSxNQUFNRSxPQUFPQyxLQUFLLEtBSGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHbUQ7QUFBQSxXQUxyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxlQUFZLFlBQ1osTUFBSyxZQUNMLE9BQU9OLFVBQ1AsVUFBVUcsV0FBT0YsWUFBWUUsTUFBTUUsT0FBT0MsS0FBSyxLQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSW1EO0FBQUEsV0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFGO0FBQUEsTUFDRSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBbEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVKO0FBQUNULEdBcENJRixXQUFTO0FBQUFZLEtBQVRaO0FBc0NOQSxVQUFVYSxZQUFZO0FBQUEsRUFDcEJaLFdBQVdGLFVBQVVlLEtBQUtDO0FBQzVCO0FBRUMsZUFBZWY7QUFBUyxJQUFBWTtBQUFBSSxhQUFBSixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJQcm9wVHlwZXMiLCJMb2dpbkZvcm0iLCJ1c2VyTG9naW4iLCJfcyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsInByb3BUeXBlcyIsImZ1bmMiLCJpc1JlcXVpcmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuXG5jb25zdCBMb2dpbkZvcm0gPSAoeyB1c2VyTG9naW4gfSkgPT4ge1xuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKTsgXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB1c2VyTG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSk7XG4gICAgc2V0VXNlcm5hbWUoJycpO1xuICAgIHNldFBhc3N3b3JkKCcnKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgICA8ZGl2PlxuICAgICAgIDxoMj5Mb2dpbjwvaDI+XG4gICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufT5cbiAgICAgICAgIDxkaXY+XG4gICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50PT5zZXRVc2VybmFtZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAvPlxuICAgICAgICAgPC9kaXY+XG4gICAgICAgICA8ZGl2PlxuICAgICAgICAgICBwYXNzd29yZFxuICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXG4gICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50PT5zZXRQYXNzd29yZChldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAvPlxuICAgICAgIDwvZGl2PlxuICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgICA8L2Zvcm0+XG4gICAgIDwvZGl2PlxuICAgKVxuIH1cblxuTG9naW5Gb3JtLnByb3BUeXBlcyA9IHtcbiAgdXNlckxvZ2luOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59XG4gXG4gZXhwb3J0IGRlZmF1bHQgTG9naW5Gb3JtIl0sImZpbGUiOiIvVXNlcnMvYWRtaW4vTWluaSBQcm9qZWN0cy9wYXJ0Mi1ub3Rlcy1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Mb2dpbkZvcm0uanN4In0=