import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ea365ae8"; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=ea365ae8"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, refs) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(refs, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.propTypes = {
  buttonLabel: PropTypes.string.isRequired
};
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxVQUFVQyxZQUFZQywyQkFBMkI7QUFDMUQsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFTQyxHQUFHSixXQUFVSyxLQUFBRCxHQUFDLENBQUNFLE9BQU9DLFNBQVM7QUFBQUgsS0FBQTtBQUM1QyxRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSVYsU0FBUyxLQUFLO0FBRTVDLFFBQU1XLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBU0gsVUFBVSxLQUFLO0FBQUEsRUFBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUFQLHNCQUFvQk0sTUFBTSxNQUFNO0FBQzlCLFdBQU87QUFBQSxNQUNMTTtBQUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxPQUFPSCxpQkFDVixpQ0FBQyxZQUFPLFNBQVNHLGtCQUFtQlAsZ0JBQU1RLGVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0QsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU9GLGlCQUFpQixXQUFVLG9CQUNwQ047QUFBQUEsWUFBTVM7QUFBQUEsTUFDUCx1QkFBQyxZQUFPLFNBQVNGLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUosR0FBQyxrQ0FBQztBQUFBRyxNQTNCSWI7QUE2Qk5BLFVBQVVjLFlBQVk7QUFBQSxFQUNwQkgsYUFBYVosVUFBVWdCLE9BQU9DO0FBQ2hDO0FBRUEsZUFBZWhCO0FBQVMsSUFBQUUsSUFBQVc7QUFBQUksYUFBQWYsSUFBQTtBQUFBZSxhQUFBSixLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJmb3J3YXJkUmVmIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsIlByb3BUeXBlcyIsIlRvZ2dsYWJsZSIsIl9zIiwiX2MiLCJwcm9wcyIsInJlZnMiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiYnV0dG9uTGFiZWwiLCJjaGlsZHJlbiIsIl9jMiIsInByb3BUeXBlcyIsInN0cmluZyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCBmb3J3YXJkUmVmLCB1c2VJbXBlcmF0aXZlSGFuZGxlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuXG5jb25zdCBUb2dnbGFibGUgPSBmb3J3YXJkUmVmKChwcm9wcywgcmVmcykgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgIHNldFZpc2libGUoIXZpc2libGUpXG4gIH1cblxuICB1c2VJbXBlcmF0aXZlSGFuZGxlKHJlZnMsICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9nZ2xlVmlzaWJpbGl0eVxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9Pntwcm9wcy5idXR0b25MYWJlbH08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfSBjbGFzc05hbWU9XCJ0b2dnbGFibGVDb250ZW50XCI+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59KVxuXG5Ub2dnbGFibGUucHJvcFR5cGVzID0ge1xuICBidXR0b25MYWJlbDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkXG59XG5cbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZSJdLCJmaWxlIjoiL1VzZXJzL2FkbWluL01pbmkgUHJvamVjdHMvcGFydDItbm90ZXMtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9