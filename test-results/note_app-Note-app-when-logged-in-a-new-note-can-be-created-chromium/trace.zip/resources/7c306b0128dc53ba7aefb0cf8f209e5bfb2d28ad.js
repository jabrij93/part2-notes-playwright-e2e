import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ea365ae8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=ea365ae8"; const ReactDOM = __vite__cjsImport1_reactDom_client.__esModule ? __vite__cjsImport1_reactDom_client.default : __vite__cjsImport1_reactDom_client;
import axios from "/node_modules/.vite/deps/axios.js?v=ea365ae8";
import App from "/src/App.jsx";
import "/src/index.css";
const notes = [""];
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, { notes }, void 0, false, {
  fileName: "/Users/admin/Mini Projects/part2-notes-frontend/src/main.jsx",
  lineNumber: 6,
  columnNumber: 61
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTzREO0FBUDVELE9BQU9BLGNBQWM7QUFDckIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU87QUFFUCxNQUFNQyxRQUFRLENBQUMsRUFBRTtBQUVqQkgsU0FBU0ksV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQUMsRUFBRUMsT0FBTyx1QkFBQyxPQUFJLFNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFrQixDQUFHIiwibmFtZXMiOlsiUmVhY3RET00iLCJheGlvcyIsIkFwcCIsIm5vdGVzIiwiY3JlYXRlUm9vdCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcydcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnXG5pbXBvcnQgJy4vaW5kZXguY3NzJztcblxuY29uc3Qgbm90ZXMgPSBbJyddXG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKDxBcHAgbm90ZXM9e25vdGVzfSAvPikiXSwiZmlsZSI6Ii9Vc2Vycy9hZG1pbi9NaW5pIFByb2plY3RzL3BhcnQyLW5vdGVzLWZyb250ZW5kL3NyYy9tYWluLmpzeCJ9